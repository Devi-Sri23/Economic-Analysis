# Measuring the Pulse of Prosperity: An Index of Economic Freedom Analysis
This project aims to analyse and visualize the Index of Economic Freedom across multiple countries to provide insights into the relationship between economic policies and national prosperity.
